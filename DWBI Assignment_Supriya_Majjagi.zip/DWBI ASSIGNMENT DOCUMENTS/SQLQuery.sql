use stage;
CREATE TABLE [Employee2](
	[BusinessEntityID] [varchar] (90)NOT NULL,
	[NationalIDNumber] [varchar](150) NOT NULL,
	[LoginID] [varchar](256) NOT NULL,
	[OrganizationNode] [varchar] (100) NULL,
	[OrganizationLevel]  [varchar] (90),
	[JobTitle] [varchar](80) NOT NULL,
	[BirthDate] [varchar] (80) NOT NULL,
	[MaritalStatus] [varchar](80) NOT NULL,
	[Gender] [varchar](90) NOT NULL,
	[HireDate] [varchar] (100) NOT NULL,
	[SalariedFlag] [varchar] (100) NOT NULL,
	[VacationHours] [varchar] (90) NOT NULL,
	[SickLeaveHours] [varchar] (90) NOT NULL,
	[CurrentFlag] [varchar] (90) NOT NULL,
	[rowguid] [varchar] (90) NOT NULL,
	[ModifiedDate] [varchar] (90) NOT NULL
	)
 select * from Employee2;